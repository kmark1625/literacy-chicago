<?php if( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar( __( 'Sidebar Courses', 'kazaz' ) ) ) : ?>
<!-- sidebar widgets -->
<?php endif; ?>