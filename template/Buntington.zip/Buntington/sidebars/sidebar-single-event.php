<?php if( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar( __( 'Sidebar Event Single', 'kazaz' ) ) ) : ?>
<!-- sidebar widgets -->
<?php endif; ?>