<?php if( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar( __( 'Sidebar Course Single', 'kazaz' ) ) ) : ?>
<!-- sidebar widgets -->
<?php endif; ?>