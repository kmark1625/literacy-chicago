<?php if( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar( __( 'Sidebar Single', 'kazaz' ) ) ) : ?>
<!-- sidebar widgets -->
<?php endif; ?>