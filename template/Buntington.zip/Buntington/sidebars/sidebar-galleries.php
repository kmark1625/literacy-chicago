<?php if( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar( __( 'Sidebar Galleries', 'kazaz' ) ) ) : ?>
<!-- sidebar widgets -->
<?php endif; ?>